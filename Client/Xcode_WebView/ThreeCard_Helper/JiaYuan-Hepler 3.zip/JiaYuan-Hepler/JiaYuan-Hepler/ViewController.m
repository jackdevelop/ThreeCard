//
//  ViewController.m
//  WebView
//
//  Created by LIDONG on 10/5/15.
//  Copyright © 2015 Kingfont. All rights reserved.
//

#import "ViewController.h"
@interface NSURLRequest (DummyInterface)
+ (BOOL)allowsAnyHTTPSCertificateForHost:(NSString*)host;
+ (void)setAllowsAnyHTTPSCertificate:(BOOL)allow forHost:(NSString*)host;

@end

@implementation NSURLRequest (DummyInterface)




// start
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return (UIInterfaceOrientationPortrait == toInterfaceOrientation);
}

- (BOOL)shouldAutorotate {
    return NO;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}
// end





+ (BOOL)allowsAnyHTTPSCertificateForHost:(NSString*)host {
    return YES;
}

@end
@interface ViewController () <UIWebViewDelegate> {
    UIWebView *mWebView;
    NSURLRequest *mAuthrizingRequest;
    NSMutableData *mReceivedData;
    BOOL mAuthorized;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    CGRect rect_screen = [[UIScreen mainScreen] bounds];
    rect_screen.origin.y += 20;
    mWebView = [[UIWebView alloc] initWithFrame:rect_screen];
    //mWebView = [[UIWebView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    //uiWebView.center =
    
    [mWebView setScalesPageToFit:YES];
    [mWebView setDelegate:self];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://mobile.gz.1251013877.clb.myqcloud.com/"] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
    [self.view setBackgroundColor:[UIColor blackColor]];
    [self.view addSubview:mWebView];
    [mWebView loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    
    if ([[[request URL] scheme] isEqualToString:@"https"]) {
        if (nil == mAuthrizingRequest && !mAuthorized) {
            NSLog(@"%@", [request URL]);
            [NSURLRequest setAllowsAnyHTTPSCertificate:YES forHost:[[request URL] host]];

            mAuthrizingRequest = request;
            
            mReceivedData = [[NSMutableData alloc] init];
            NSURLConnection* conn = [[NSURLConnection alloc] initWithRequest:mAuthrizingRequest delegate:self];
            [conn start];
            return NO;
        }
    }
    
    return YES;
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    NSLog(@"webview %@", error);
}

- (void)connection:(NSURLConnection *)connection willSendRequestForAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge
{
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust])
    {
        [challenge.sender useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
    }
    else
    {
        [challenge.sender continueWithoutCredentialForAuthenticationChallenge:challenge];
    }
}
// We use this method is to accept an untrusted site which unfortunately we need to do, as our PVM servers are self signed.
- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    return request;
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSLog(@"response: \n%@", response);
    if (mAuthrizingRequest) {
        if (200 == [(NSHTTPURLResponse *)response statusCode]) {
            mAuthorized = YES;
            [mWebView loadRequest:mAuthrizingRequest];
        }
        mAuthrizingRequest = nil;
    }
}

- (void)connection:(NSURLConnection *)connection
    didReceiveData:(NSData *)data {
    [mReceivedData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    NSLog(@"%s", __PRETTY_FUNCTION__);
}
@end
